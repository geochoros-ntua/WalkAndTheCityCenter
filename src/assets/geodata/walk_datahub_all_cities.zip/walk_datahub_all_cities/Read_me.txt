- Walk & the City Center is a research project of GeoCHOROS-Research Group at the National Technical University of Athens, Greece, 
http://geochoros.survey.ntua.gr/walkandthecitycenter/home

- Methodological details about our tabular and spatial data can be seen in the data article: 
Bartzokas-Tsiompras, A., Photis, Y., Tsagkis, P., & Panagiotopoulos, G. (2021 - Under Review). 
Microscale walkability indicators for fifty-nine European central urban areas: An open-access tabular dataset and geospatial web-based platform. Data in Brief.

- You are advised to read the disclaimer (.txt) file carefully.

- Field names description (all_cities.shp):
 
	  "Column Code":"Score",
          "Indicator Name":"Walkability Score"
	"Description: "This indicator describes the density of microscale walkability scores per segment (km per square km).
	The score formula for each street-and crossing-segment (polyline) is the following: 
	WS=SUM(S1_1+S2_1+S2_2+S3_1+S3_2+S4_1+S5_1+S5_2+S6_1+S7_1+S8_1+S8_2+S9_1+S10_1+S1 1_1+S12_1+S12_2+S13_1+S14_1+S14_2+C11_1+C12_1+C12_2+C13_1)/31
	Where WS is the microscale walkability score per segment, S#_# & C##_# are the codes of each individual audit item, and 31 is the maximum number of points that a segment can receive."
       
          "Column Code":"S1_0",
          "Indicator Name":"Land Use: Non-Commercial/Non-Entertainment Activities"
       
       
          "Column Code":"S1_1",
          "Indicator Name":"Land Use: Mainly Commercial/Entertainment Activities"
       
       
          "Column Code":"S2_0",
          "Indicator Name":"Parks/Plazas: No"
       
       
          "Column Code":"S2_1",
          "Indicator Name":"Parks/Plazas: 1 Access Point"
       
       
          "Column Code":"S2_2",
          "Indicator Name":"Parks/Plazas: 2+ Access Points"
       
       
          "Column Code":"S3_0",
          "Indicator Name":"Transit Stops: No"
       
       
          "Column Code":"S3_1",
          "Indicator Name":"Transit Stops: 1"
       
       
          "Column Code":"S3_2",
          "Indicator Name":"Transit Stops: 2+"
       
       
          "Column Code":"S4_0",
          "Indicator Name":"Public Seating: No"
       
       
          "Column Code":"S4_1",
          "Indicator Name":"Public Seating: Yes"
       
       
          "Column Code":"S5_0",
          "Indicator Name":"Street Lights: None"
       
       
          "Column Code":"S5_1",
          "Indicator Name":"Street Lights: Some"
       
       
          "Column Code":"S5_2",
          "Indicator Name":"Street Lights: Plenty"
       
       
          "Column Code":"S6_0",
          "Indicator Name":"Buildings Well-maintained: No"
       
       
          "Column Code":"S6_1",
          "Indicator Name":"Buildings Well-maintained: Yes"
       
       
          "Column Code":"S7_0",
          "Indicator Name":"Graffitti: Yes"
       
       
          "Column Code":"S7_1",
          "Indicator Name":"Graffitti: No"
       
       
          "Column Code":"S8_0",
          "Indicator Name":"Bike Lane: No"
       
       
          "Column Code":"S8_1",
          "Indicator Name":"Bike Lane: Painted Line"
       
       
          "Column Code":"S8_2",
          "Indicator Name":"Bike Land: Protected from traffic"
       
       
          "Column Code":"S9_0",
          "Indicator Name":"Sidewalk: Absent"
       
       
          "Column Code":"S9_1",
          "Indicator Name":"Sidewalk: Present"
       
       
          "Column Code":"S10_0",
          "Indicator Name":"Sidewalk Well-maintained: No or No Sidewalk Present"
       
       
          "Column Code":"S10_1",
          "Indicator Name":"Sidewalk Well-maintained: Yes"
       
       
          "Column Code":"S11_0",
          "Indicator Name":"Sidewalk Buffers: No or No Sidewalk Present"
       
       
          "Column Code":"S11_1",
          "Indicator Name":"Sidewalk Buffers: Yes or Pedestrian Street"
       
       
          "Column Code":"S12_0",
          "Indicator Name":"Sidewalk Shading/Overhead Coverage: 0% - 25% (length) or  No Sidewalk Present"
       
       
          "Column Code":"S12_1",
          "Indicator Name":"Sidewalk Shading/Overhead Coverage: 26% - 75% (length)"
       
       
          "Column Code":"S12_2",
          "Indicator Name":"Sidewalk Shading/Overhead Coverage: 76% - 100% (length)"
       
       
          "Column Code":"S13_0",
          "Indicator Name":"Sidewalk Width: Less than 2 m or No Sidewalk Present"
       
       
          "Column Code":"S13_1",
          "Indicator Name":"Sidewalk Width: Greater than 2 m"
       
       
          "Column Code":"S14_0",
          "Indicator Name":"Traffic: More than 4 lanes"
       
       
          "Column Code":"S14_1",
          "Indicator Name":"Traffic: 2 - 3 lanes"
       
       
          "Column Code":"S14_2",
          "Indicator Name":"Traffic: Single lane or pedestrian street"
       
       
          "Column Code":"C11_0",
          "Indicator Name":"Crossing - Pedestrian Walk Signal: No"
       
       
          "Column Code":"C11_1",
          "Indicator Name":"Crossing - Pedestrian Walk Signal: Yes"
       
       
          "Column Code":"C12_0",
          "Indicator Name":"Crossing - Curb ramp(s): No"
       
       
          "Column Code":"C12_1",
          "Indicator Name":"Crossing - Curb ramp(s): Yes, At one curb only"
       
       
          "Column Code":"C12_2",
          "Indicator Name":"Crossing - Curb ramp(s): Yes, at both pre- and post-crossing curbs"
       
       
          "Column Code":"C13_0",
          "Indicator Name":"Crossing - Pedestrian Crosswalk: No"
       
       
          "Column Code":"C13_1",
          "Indicator Name":"Crossing - Pedestrian Crosswalk: Yes"